<ul class="insights">
  <li>
    <i class='bx bx-car'></i>
    <span class="info">
      <h3>10</h3>
      <p>Total Vehicles</p>
    </span>
  </li>
  <li>
    <i class='bx bx-male'></i>
    <span class="info">
      <h3>10</h3>
      <p>Total Customers</p>
    </span>
  </li>
  <li>
    <i class='bx bx-line-chart'></i>
    <span class="info">
      <h3>10</h3>
      <p>Services</p>
    </span>
  </li>
  <li>
    <i class='bx bx-money'></i>
    <span class="info">
      <h3>Rs.742,000</h3>
      <p>Total Sales</p>
    </span>
  </li>
</ul>