<div class="header">
  <div class="left">
    <h1>Dashboard</h1>
  </div>
  <a href="#" class="report">
    <i class='bx bx-cloud-download'></i>
    <span>Download CSV</span>
  </a>
</div>