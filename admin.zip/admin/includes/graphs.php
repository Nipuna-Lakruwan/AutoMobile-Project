<div class="graphBox">
  <div class="box">
    <canvas id="myChart"></canvas>
  </div>
  <div class="box">
    <canvas id="earning"></canvas>
  </div>
</div>